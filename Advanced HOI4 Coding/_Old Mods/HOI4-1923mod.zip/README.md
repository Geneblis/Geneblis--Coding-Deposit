This project is no longer active and all its files free to use under the GPL.
